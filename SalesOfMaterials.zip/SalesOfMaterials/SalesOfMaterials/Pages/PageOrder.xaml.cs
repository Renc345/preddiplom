﻿using Microsoft.Office.Interop.Excel;
using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Excel = Microsoft.Office.Interop.Excel;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOrder.xaml
    /// </summary>
    public partial class PageOrder : System.Windows.Controls.Page
    {
        public PageOrder()
        {
            InitializeComponent();
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            switch (Users.GetUsers.IdTypesEmployee)
            {
                case 1:
                    System.Windows.Controls.MenuItem item = new System.Windows.Controls.MenuItem() { Header = "Добавить новый заказ", Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/Photo/iconadd.png")) } };
                    item.Click += btnAddOrder_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item);
                    System.Windows.Controls.MenuItem item1 = new System.Windows.Controls.MenuItem() { Header = "Распределить", Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/Photo/icondistribution.png")) } };
                    item1.Click += btnDistribution_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2,item1);
                    break;
                case 2:
                    System.Windows.Controls.MenuItem item2 = new System.Windows.Controls.MenuItem() { Header = "Добавить новый заказ", Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/Photo/iconadd.png")) } };
                    item2.Click += btnAddOrder_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item2);
                    break;
                case 3:
                    System.Windows.Controls.MenuItem item3 = new System.Windows.Controls.MenuItem() { Header = "Распределить", Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/Photo/icondistribution.png")) } };
                    item3.Click += btnDistribution_Click;
                    dgExpenseIvoices.ContextMenu.Items.Insert(2, item3);
                    break;
            }
        }

        private void dgExpenseIvoices_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (dgExpenseIvoices.SelectedItem != null)
                ClassFrame.frmObj.Navigate(new PageExpenseComposition((ExpenseIvoices)dgExpenseIvoices.SelectedItem));

        }

        private void btnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TxtOrder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtOrder.Text.Count() != 0)
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.Where(x => x.Employee.FIO.ToLower().Contains(TxtOrder.Text.ToLower()) || x.Сounterparties.Nazv_Сounterparties.ToLower().Contains(TxtOrder.Text.ToLower())).ToList();
            else dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void btnDistribution_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DistributionWarehouse((ExpenseIvoices)dgExpenseIvoices.SelectedItem));
        }

        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            List<ExpenseIvoices> OrderForRemoving = dgExpenseIvoices.SelectedItems.Cast<ExpenseIvoices>().ToList();
            if (MessageBox.Show("Удалить заказы", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (ExpenseIvoices o in OrderForRemoving)
                    {
                        List<ExpenseComposition> list = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices).ToList();
                        foreach (ExpenseComposition c in list)
                            ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Movement where idComposition = @com and ArrivalOrExpenditure = 1", new SqlParameter("@com", c.IdExpenseComposition));
                        ClassFrame.db.ExpenseComposition.RemoveRange(ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == o.IdExpenseIvoices));
                    }
                    ClassFrame.db.ExpenseIvoices.RemoveRange(OrderForRemoving);
                    ClassFrame.db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }
                MessageBox.Show("Данные удаленны");
                dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
            }
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddOrder(null));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgExpenseIvoices.ItemsSource = ClassFrame.db.ExpenseIvoices.ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void MenuExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application app = new Excel.Application();
            Workbook wb = app.Workbooks.Add();
            Worksheet worksheet = app.Worksheets.Item[1];
            ExpenseIvoices i = dgExpenseIvoices.SelectedItem as ExpenseIvoices;
            worksheet.Cells[1][1] = $"Накладная №{i.IdExpenseIvoices}";
            worksheet.Cells[1][3] = $"Менеджер: {i.Employee.FIO}";
            worksheet.Cells[1][5] = $"Контрагент: {i.Сounterparties.Nazv_Сounterparties}";
            worksheet.Cells[1][6] = $"ИНН: {i.Сounterparties.Adress_Сounterparties}";
            worksheet.Cells[1][7] = $"Адрес: {i.Сounterparties.INN}";
            int indexRows = 9;
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Материал";
            worksheet.Cells[3][indexRows] = "Количество";
            worksheet.Cells[4][indexRows] = "Цена";
            worksheet.Cells[5][indexRows] = "Сумма";
            List<ExpenseComposition> printItems = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == i.IdExpenseIvoices).ToList();
            foreach (ExpenseComposition item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows - 8;
                worksheet.Cells[2][indexRows + 1] = item.Material.Name;
                worksheet.Cells[3][indexRows + 1] = item.Quantity;
                worksheet.Cells[4][indexRows + 1] = item.Price;
                worksheet.Cells[5][indexRows + 1] = item.Quantity * item.Price;
                
                indexRows++;
            }
            Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],worksheet.Cells[5][indexRows + 1]];
            range.ColumnWidth = 30; 
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            app.Visible = true;
        }
    }
    
}
