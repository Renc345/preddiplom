﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Storage
    {
        public int idStorage { get; set; }
        public int idWarehouse { get; set; }
        public int idMaterial { get; set; }
        public int Quantity { get; set; }
        public int QuantityComposition { get; set; }
        public virtual Warehouses Warehouse { get { return ClassFrame.db.Database.SqlQuery<Warehouses>($"select * from Nomenclature.dbo.Warehouses where idWarehouse = {idWarehouse}").First(); } }
        public virtual Materials Material { get { return ClassFrame.db.Database.SqlQuery<Materials>($"select * from Nomenclature.dbo.Materials where idMaterial = {idMaterial}").First(); } }

    }

}
